# -*- coding: utf-8 -*-
import os
# uncomment the following in windows and set the GEDAL_DIR
# GDAL_DIR = "path/to/gdal"
# os.environ["Path"] = GDAL_DIR + ";" + os.environ["Path"]
# os.environ["GEOS_LIBRARY_PATH"] = os.path.join(GDAL_DIR, "geos_c.dll")
# os.environ["GDAL_LIBRARY_PATH"] = os.path.join(GDAL_DIR, "gdal111.dll")